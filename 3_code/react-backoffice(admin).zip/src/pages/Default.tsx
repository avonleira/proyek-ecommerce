import { Typography } from '@mui/material';

export default function Default() {
  return (
    <Typography>
      Default Page
    </Typography>
  )
}
