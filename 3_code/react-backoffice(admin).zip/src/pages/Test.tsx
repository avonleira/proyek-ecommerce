import { useEffect, useState } from "react"
import { Typography } from "@mui/material"

interface IProps {}

export default function Test(props: IProps) {
  return (
    <Typography>
      {"This is a test Page!"}
    </Typography>
  )
}
