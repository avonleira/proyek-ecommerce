export const carouselItems = [
  { title: "Slider 1", alt: "Gambar Slider 1", src: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fcarousel%2Falvaro-reyes-MEldcHumbu8-unsplash.jpg?alt=media&token=b67e857e-c578-4743-8b0c-47d6681f199d", path: "/promo/1" },
  { title: "Slider 2", alt: "Gambar Slider 2", src: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fcarousel%2Fglenn-carstens-peters-npxXWgQ33ZQ-unsplash.jpg?alt=media&token=cb3666b6-0847-4bbf-a802-37ac3afa183a", path: "/promo/2" },
  { title: "Slider 3", alt: "Gambar Slider 3", src: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fcarousel%2Fm-ZzOa5G8hSPI-unsplash.jpg?alt=media&token=186f9553-2072-4770-a178-4e2009c702a3", path: "/promo/3" },
  { title: "Slider 4", alt: "Gambar Slider 4", src: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fcarousel%2Fthought-catalog-505eectW54k-unsplash.jpg?alt=media&token=96651f96-341b-4b68-bf72-cb8a96377cf3", path: "/promo/4" },
  // { title: "Slider ", alt: "Gambar Slider ", src: "", path: "/promo/" },
]