export interface ImageInterface {
  title?: string
  src: string
  alt?: string
  loading?: "lazy"
}