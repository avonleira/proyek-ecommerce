export const names = [
  "Hendra Liu", "Melisa", "Joseph", "Nathaniel", "Hilda", "Alex Wu", "Bambang", "Clarine", "Juan", "Jennifer", "Ling", "Michael Geraldo",
  "Laura", "Christian Jason", "Jonathan", "Putri", "Willy", "Jhonny", "Matthew", "Erick", "Eunike", "Jessica", "Gentrix", "Helpi",
  "Andreas", "Michelle", "Gerard", "Maylia", "Cristianto", "Kezia", "Phebee", "Haidee", "Chandra", "Valerie", "Julio", "Daniel",
  "Anton Gunarto", "James Minandar", "Nita", "Yendy", "Haryanto", "Juli", "Ronald", "Ishak", "Liman", "Ema", "Teddy", "Wenny Handoko",
  "Lenny", "Merry", "July", "Diana", "Tan Giok Eng", "Hartono", "Krestian", "Wiwin", "Ayen", "Hasan", "Lanny", "Aimee", "Martha",
  "Sharen", "Rachel", "Rahel", "Julio Fandy", "Gunaryo",
]

export const randomName = () => `eg: ${names[Math.floor(Math.random() * names.length)]}`;