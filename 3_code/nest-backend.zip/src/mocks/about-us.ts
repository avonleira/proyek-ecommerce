export const mockAboutUs = {
    main_banner: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fproducts%2Fdigital-alliance-d4-mousepad-gaming-m%2Fmousepad-1.jpg?alt=media&token=362269ca-54b0-4f9e-8b9c-1f591022990b",
    visi: "Visi Menjadi tempat belanja online yang terpercaya dan memberikan kualitas terbaik dari segi mutu maupun pelayanan terhadap konsumen.",
    misi: [
        {
            urutan: 1, 
            content: "Melayani segala kebutuhan pembeli baik mulai dari pemesanan hingga pengiriman barang sampai di tempat pembeli."
        }
    ],
    partner: [
        {
            img_url: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fproducts%2Fdigital-alliance-d4-mousepad-gaming-m%2Fmousepad-1.jpg?alt=media&token=362269ca-54b0-4f9e-8b9c-1f591022990b", 
        },
        {
            img_url: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fproducts%2Fdigital-alliance-d4-mousepad-gaming-m%2Fmousepad-1.jpg?alt=media&token=362269ca-54b0-4f9e-8b9c-1f591022990b", 
        },
        {
            img_url: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fproducts%2Fdigital-alliance-d4-mousepad-gaming-m%2Fmousepad-1.jpg?alt=media&token=362269ca-54b0-4f9e-8b9c-1f591022990b", 
        },
        {
            img_url: "https://firebasestorage.googleapis.com/v0/b/duta-tech.appspot.com/o/images%2Fproducts%2Fdigital-alliance-d4-mousepad-gaming-m%2Fmousepad-1.jpg?alt=media&token=362269ca-54b0-4f9e-8b9c-1f591022990b", 
        },

    ]
}