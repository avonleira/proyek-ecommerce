export enum GenderType {
  Male = "male",
  Female = "female"
}

export enum PromoType {
  PERCENTAGE = "percentage",
  FIXED = "fixed"
}